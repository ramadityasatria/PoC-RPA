// STSample.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "../../../../Contents/src/Include_ST/STOperatorApp.h"
#include "../../../../Contents/src/Include_ST/STActor.h"
#include "../../../../Contents/src/Include_ST/ScriptDef.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//
void STmain(CSTActor* pSTActor);

CSTOperatorApp theApp;

char* g_szSrc[] = {	
"Inputs: Period1(14),Price(close);",
"Plot1(VHF(Period1,Price), \"VHF\");",
	"#"};

char* g_szInputs[] = {	
"Period1(14)",
"Price(close)",
	"#"};


char* g_szUserID = "";
char* g_szPassword = "";
long g_lExpiredDate = 0;
long g_lSourceType = 0;	// 0: Pascal, 1:VisualBasic
BOOL g_bUseUserID = 0;
BOOL g_bUsePassword = 0;
BOOL g_bUseExpiredDate = 0;

LPCTSTR WINAPI fnGetUserID()
{
	return g_szUserID;
}

LPCTSTR WINAPI fnGetPassword()
{
	return g_szPassword;
}

long WINAPI fnGetExpiredDate()
{
	return g_lExpiredDate;
}

long WINAPI fnGetSourceType()
{
	return g_lSourceType;
}

long WINAPI fnGetUseUserID()
{
	return g_bUseUserID;
}

long WINAPI fnGetUsePassword()
{
	return g_bUsePassword;
}

long WINAPI fnGetUseExpriedDate()
{
	return g_bUseExpiredDate;
}

long WINAPI fnLoadST(HWND hParent, HWND hSocket, CDBMgr* pDBMgr, long lKey, LPCTSTR lpSTName, int nSTPos, LPCTSTR lpAdditionalOption)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return theApp.LoadST(STmain
							, hParent
							, hSocket
							, pDBMgr
							, lKey
							, lpSTName
							, nSTPos
							, lpAdditionalOption
							, g_szInputs
							, g_szUserID
							, g_szPassword
							, g_lExpiredDate
							, g_lSourceType
							, g_bUseUserID
							, g_bUsePassword
							, g_bUseExpiredDate	);
}

long WINAPI fnUnloadST(long lSTActor)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return theApp.UnloadST(lSTActor);
}

BOOL WINAPI fnExecuteST(long lSTActor,LPCTSTR lpInputData)
{
	return theApp.ExecuteST(lSTActor,lpInputData);
}

BOOL WINAPI fnStopST(long lSTActor)
{
	return theApp.StopST(lSTActor);
}

BOOL WINAPI fnPauseST(long lSTActor)
{
	return theApp.PauseST(lSTActor);
}

BOOL WINAPI fnUpdateST(long lSTActor,long lPos, BOOL bIsUpdateData)
{
	return theApp.UpdateST(lSTActor,lPos,bIsUpdateData);
}


BOOL WINAPI fnCommandST(long lSTActor, LPCTSTR lpCommand, LPCTSTR lpOption)
{
	return theApp.CommandST(lSTActor,lpCommand,lpOption);
}

// Input From Outer
double WINAPI fnSubInFuncST(long lSTActor,long lIndex, BOOL bTemp0, BOOL bTemp1,BOOL bTemp2 , BOOL bTemp3 ,BOOL bTemp4 , BOOL bTemp5 ,BOOL bTemp6 , BOOL bTemp7 ,BOOL bTemp8 , BOOL bTemp9 )
{
	return 0;
}

CString WINAPI fnGetSrc(long lIndex, LPCTSTR lpUserIDIn, LPCTSTR lpPasswordIn, long lTodayDateIn)
{
	CString strMyPassword;
	CString strUserID;
	if(g_szUserID)
	{
		strUserID = g_szUserID;
	}
	if(g_szPassword)
	{
		strMyPassword = g_szPassword;
	}
	if(	(strUserID.IsEmpty()||strUserID==lpUserIDIn)
		&&(strMyPassword.IsEmpty()||strMyPassword==lpPasswordIn)
		&&!g_lExpiredDate||lTodayDateIn<=g_lExpiredDate)
	{
		return g_szSrc[lIndex];
	}
	return "";	
}

CString WINAPI fnGetInputs(long lIndex)
{
	return g_szInputs[lIndex];
}


void STmain(CSTActor* pSTActor)
{
pSTActor->DeclareInnerFunc(g_lSourceType, 0, "VHF");
pSTActor->DeclareInnerFunc(g_lSourceType, 1, "PLOT1");
INPUTS(0, Period1, NumericSeries, 0);
INPUTS(1, Price, NumericSeries, 0);
pSTActor->InnerFunc(g_lSourceType, 1, 0, pSTActor->InnerFunc(g_lSourceType, 0, 0, GETINPUTHOLDERDATA(0, 0), GETINPUTHOLDERDATA(1, 0)), "VHF", -1);
}
